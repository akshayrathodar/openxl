import React from 'react';

export const Heading1 = props => {
    return(
        <>  
            <h1>{props.title}</h1>
        </>
    );
}
